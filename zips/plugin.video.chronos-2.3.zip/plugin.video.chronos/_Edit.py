import xbmcaddon

MainBase     = 'http://www.skydarks.com/chronos/home.txt'
#AdultContent = 'http://www.skydarks.com/adult/adult.txt'
LiveSport    = 'http://www.skydarks.com/chronos/sports.txt' # path for home of playlist sports
facebook_url = 'Join our FaceBook Group https://www.facebook.com/groups/skydarks/' # leave as '' if not required
twitter_url  = 'if you wish to donate and help paypal.me/swiperdan' # leave as '' if not required
addon        = xbmcaddon.Addon('plugin.video.chronos')