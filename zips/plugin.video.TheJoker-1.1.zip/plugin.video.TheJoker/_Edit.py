import xbmcaddon

MainBase = 'http://jokerswizard.esy.es/joker/home/home.txt'
addon = xbmcaddon.Addon('plugin.video.TheJoker')