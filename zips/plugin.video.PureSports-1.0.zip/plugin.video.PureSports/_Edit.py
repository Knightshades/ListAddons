import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/PureRepo1/PureRepo/master/PureSports/Main.xml'
addon = xbmcaddon.Addon('plugin.video.PureSports')