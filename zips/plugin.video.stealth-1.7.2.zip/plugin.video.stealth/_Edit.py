import xbmcaddon

MainBase = 'http://andybuilds.darkwebrepo.gq/addonfiles/Home.txt'
addon = xbmcaddon.Addon('plugin.video.stealth')