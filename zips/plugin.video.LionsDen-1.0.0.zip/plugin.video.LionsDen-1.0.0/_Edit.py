import xbmcaddon

MainBase = 'https://www.dropbox.com/s/puisr7juzzxnvlg/home.txt?dl=1'
addon = xbmcaddon.Addon('plugin.video.LionsDen')