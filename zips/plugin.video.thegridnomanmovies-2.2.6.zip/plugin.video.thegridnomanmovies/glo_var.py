#######################################################################
#Import Modules and or Scripts
import xbmcaddon
#######################################################################

#######################################################################
#You can change the colors of your wizard text here. 
#Please do not edit # or change COLOR1 or it will break all the colors 
# in the entire wizard!
# For a complete list of colors available please visit
# http://forum.kodi.tv/showthread.php?tid=210837
COLOR               = '[COLOR red][B]'
COLOR1              = '[/B][/COLOR]'
#######################################################################
#Editable Global Variables and Notification Settings
#######################################################################
#This should MATCH your plugin name exactly.
addon               = xbmcaddon.Addon('plugin.video.thegridnomanmovies')
#######################################################################
#This is the URL to the directory where your .txt files are
#located on your host.
MainBase            = 'https://addongrid.000webhostapp.com/addons/nomanmovies/moviedocs/dir/dir.xml'
#######################################################################
#You can change this to match your wizard name if you would like. 
#Please be sure to leave a space after the same before the ' at the end.
GROUP_NAME          = 'Noman Movies '
#######################################################################
#Search Directory URL Goes here
SEARCH              = 'https://addongrid.000webhostapp.com/addons/nomanmovies/moviedocs/dir/searchdir.xml'
#######################################################################