# Truth Videos #
Repository for the Kodi addon Truth Videos

Support / Coments via Twitter: @Truth_Videos

WAKE UP SHEEPLE!

# CHANGELOG
see changelog.txt
