import xbmcaddon
# 2018-05-13 
#####--Addon details--#####
'''change name to that of your addon, same as file name'''
addon = xbmcaddon.Addon('plugin.video.SportsMatrix') 

####--Route to text file--######
'''change Mainbase URL link to the URL of your 1st text file or home text file and encode using encoder If you have a backup of txt on another server put URL in backup will swap servers if a error occurs'''
MainBase = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2dIRkJLSDR5'
BackUp   = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2dIRkJLSDR5'
PopUpNotice = 'https://pastebin.com/raw/J6GyNrjm'

####----Search Functions----####
''' True if you wish to search for this content within addon or False if not, Search movie and tv will use the TMDB api to pull list of movies or tv shows relating to the search then will search the addon for that content, Search Content will take a direct input string and search the addon this is mainly for addons that are not movie or tv content and not using the TMDB api Key, You can also customize the message for the search input keyboard '''
Enable_Search_Dir = False
Search_Movies     = True
Search_Tv         = True
Search_Content    = True
Search_Content_KeyBoardMsg = 'Change here to your own message'
#####-----TMDB------######
####----TMDB Lists----####
"""For return on TMDB Movie lists you can either search addon for content or use uni scraper to find content in TMDBMovieList enter either 'search_addon' or 'search_internet' as a string """
TMDBMovieList = 'search_internet'

####---API Keys--####
'''if you are to use own api key and wish to use it in addon for all insert here also in settings is a place to enter the key Edit UseTMDB to False, api key requires encoding the same way as MainBase is  '''
UseTMDB  = True
TMDB_api = 'd2779ce965c0f5c2c3917840e9f218b7'
#####-----Text-----#####
'''where several strings are joined to create a name for a directory input your delimiter, if you would like a space before and or after the delimiter modify TxtDelimiterAddSpaces to both,after,before'''
TxtDelimiter = '|'
TxtDelimiterAddSpaces = 'Both'
TxtDelimiterAddSpacesAmount = 2
TxtDelimiterColor = 'yellow'
#####---Text Color---#####
'''Enter text color you wish the title to be if just a color is required set TxtColor1 to a color, if splitting for 2 colors add TxtColor2, TxtSplit is point of change color can be space or word, if word is used a value must be entered in TxtSpoint so if 2 is enter the color will change at 2nd letter of the word it will only do the 1st 2 words of the string same with using space '''
#####-----Channel text color set up----#####
ChannelTxtColor1 = 'blue'
ChannelTxtColor2 = 'white'
ChannelTxtSplit  = 'space'
ChannelTxtSpoint = ''
#####-----Item text color set up -----#####
ItemTxtColor1    = 'orange'
ItemTxtColor2    = 'limegreen'
ItemTxtSplit     = 'word'
ItemTxtSpoint    = '2'
####-----Dialog Boxes-----#####
'''Colors for pop up dialog boxes text '''
DialogBoxColor1 = 'yellowgreen'
DialogBoxColor2 = 'steelblue'

#####--Art Work--#####
'''Change these paths if you wish to use custom art work for hard coded sections favorites,settings,history, DailyMotion, Search ,Next page or YouTube icons, 5 icons are already stored but you may wish to use your own to change you can either replace the icons in the resources/art folder remember to keep the name the same or put a URL in the paths below. If you wish to use custom fanart for theses sections enter a URL in to the path else the standard fanart will be used'''
DailyMotionIcon   = ''
DailyMotionFanart = ''
FavoriteIcon      = ''
FavoriteFanart    = ''
HistoryIcon       = ''
HistoryFanart     = ''
NextPageIcon      = ''
SearchIcon        = ''
SearchFanart      = ''
SettingIcon       = ''
SettingFanart     = ''
TmdbIcon          = ''
TmdbFanart        = ''
YouTubeIcon       = '' #channel listings only text file and hard code YouTube Search 
YouTubeFanart     = ''
'''You tube search list does not pull any fanart if default will be standard fanart of addon if you would like to use custom enter URL in between speech marks empty speech marks will use default'''
YT_SearchFanart = ''
'''Podcast info puller use icon image as fanart most images pulled are good enough to use as fanart set to False if you wish to use addon fanart'''
PodcastFanart = True

#####--PodCast--#####
'''For using the Podcast RSS puller you can preset the length of the list of returned Podcasts if you wish to restrict the length of list change PodcastListSetLength to True and PodcastListLength enter the value as a int of the number wanting returned also in user settings the end user may set there own amount '''
PodcastListSetLength = False
PodcastListLength = ''


#####-----Universal Scrapers-----#####
'''Show progress dialog of scrapers running if False standard rotating circle will show 
For the order in which the links will be listed, UniSortMethods 'quality','source', if left blank a Random sort method will be applied, changing UniSortReverse to True will reverse order the list only works in combination with UniSortMethod if a string is added ie 'quality'
if UniDialogSelect is True the returned list will be displayed as a dialog select box, False will be displayed as standard directory   '''
UniShowProgress = True
UniSortMethod = ''
UniSortReverse = False
UniDialogSelect = False 

######-------Tools settings-------######
''''To display tool/setting directory use True to Hide use false'''
Enable_ToolsSetting_Dir = True

#####-----Pop Up Dialog-----#####
'''Header and Body BaseColor is "white" or "black",Header and Body BaseTrans is how transparent the base is 50, 75 or 100 as a percentage, colors can be sent as word that kodi uses or as a hex code '''
guiHeaderBaseColor = 'white'
guiHeaderBaseTrans = '100'
guiHeaderColor = 'lime'
guiHeaderTxtColor = 'orangered'
guiHeaderTxtShadow = 'white'
guiBodyBaseColor = 'white'
guiBodyBaseTrans = '75'
guiBodyColor     = 'mediumblue'
guiBodyTxtColor = 'white'
guiBodyTxtShadow = 'navy'
guiSliderBarColor = 'yellow'
guiSliderColorNoFocus = 'yellowgreen'
guiSliderColorFocus = 'gold'
guiButtonColorNoFocus = 'violet'
guiButtonColorFocus = 'purple'
guiButtonTxtColor = 'cyan'


#####--Hard Coding settings--###(Not function yet!!!!)
'''use text files as source of content and menu's it is possible to use a mixture of both'''
HCS_text = True
'''use hard coded directories change to true if you want to use other methods of adding content other then text files'''
HCS_addDir = False

'''#####-----Update notes -------#######
2018-06-04 Added Variables for custom gui dialogs,Added variable for search addon pop up message on keyboard
2018-05-24 Added variables for TMDB Lists
2018-05-13 Added variables for string delimiter 
2018-05-06 Added Variables for text color 
2018-04-30 Added variables for My TMDB and Search
2018-04-17 Added backup server option 
2018-04-16 Added Podcast settings
2018-04-11 Added TMDB settings 
2018-04-09 Added option for History Icon and fanart'''