###########################################################################################################
#Import Modules and or Scripts
import sys
import plugintools
import xbmcaddon
from addon.common.addon import Addon
###########################################################################################################

###########################################################################################################
#Please change the addonID to match your folder / addon name exactly.
addonID = 'plugin.video.thegridyoutube'
###########################################################################################################
#Feel free to change the color name in cr or cr1, do not edit cr2!
cr     = '[COLOR red][B]'
cr1    = '[COLOR snow][B]'
cr2    = '[/B][/COLOR]'
###########################################################################################################

###########################################################################################################
#Please do not edit these variables
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
###########################################################################################################

###########################################################################################################
#Channels and or Users Information from YouTube goes here
#Example:
#a1 = "The name of the channel or user goes here"
#a2 = "The channel or user /id goes here"
#a3 = 'The image icon url for the channel or user goes here'
#You can have as many channels / users as you wish, just be sure that you have a matching pair. For every
#letter number e1,e2,e3 you will also need to have (e1,e2,e3), 
###########################################################################################################
a1     = cr+"TheGrid Tutorial"+cr2
a2     = "channel/UCtFr3g23V7bhqoh0FG6YokQ"
a3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
b1     = cr1+"Tk's Kodi Video"+cr2
b2     = "channel/UC5TH_RN1cTiAGJyj6BpUH0g"
b3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
c1     = cr+"Top Tutorial"+cr2
c2     = "channel/UC0QRG-gMqHhF5-BPdmJfs1w"
c3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
d1     = cr1+"Simple Kore"+cr2
d2     = "channel/UCgC_gjO6044hDD6RRm5o7Iw"
d3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
e1     = cr+"TotalRevolution"+cr2
e2     = "channel/UCTj-2nCE8B_3AvEGAKVyn1g"
e3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
f1     = cr1+"XC Techs"+cr2
f2     = "channel/UCYxuwrRSvZR3FW757cpK0wA"
f3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
g1     = cr+"Husham Memar"+cr2
g2     = "channel/UCb5DkdbEOBNoOY7RGkGN4pg"
g3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
h1     = cr1+"XBMCONNECT"+cr2
h2     = "channel/UCWM6C2mZAhTAOVUi3tDWeCw"
h3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
i1     = cr+"Tech Timeruuu"+cr2
i2     = "channel/UCoMOQDEEBECQ81CdojuEqfg"
i3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
j1     = cr1+"Solo Man"+cr2
j2     = "channel/UCuSdObYHdjize3ziP951org"
j3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
k1     = cr+"DaButcher Builds"+cr2
k2     = "channel/UC-jBkGiRokRd-B2ylx1VqJQ"
k3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
l1     = cr1+"Dimitrology"+cr2
l2     = "channel/UCUY5BYXIaZoa4-HclwnNWDA"
l3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
m1     = cr+"Simple TechNerd"+cr2
m2     = "channel/UCkrTNfheGU0L4W-_5C3VFqA"
m3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
n1     = cr1+"John Henderson"+cr2
n2     = "channel/UCn9O8-AkpJZ9OCYzkyj3rFA"
n3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
o1     = cr+"Mchanga"+cr2
o2     = "channel/UCgTv3f2aLsOsgeaQ9MnS1wg"
o3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
p1     = cr1+"Kodi No Limits"+cr2
p2     = "channel/UCGsUwQz0b6_GnabWypEr39A"
p3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
q1     = cr+"KoDYI Help"+cr2
q2     = "channel/UCuXIo3ITGwumJ9JzDyQ5x3A"
q3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
r1     = cr1+"Mike Anning"+cr2
r2     = "channel/UCO-tVbRdSCmsowpz7CfzTbw"
r3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
s1     = cr+"Doc Sqiiffy"+cr2
s2     = "channel/UCFOStcorp34JSwYTaTZB1oQ"
s3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
t1     = cr1+"Gray3dfx Tech"+cr2
t2     = "channel/UCX5fJhHPuXvyJFu2d0nCIrA"
t3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
u1     = cr+"Project Kodi"+cr2
u2     = "channel/UCePmNnCSc0WjtZe6GxGT30w"
u3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
v1     = cr1+"Lee TV"+cr2
v2     = "channel/UCSA4F9D70u72qUr3lkrF09A"
v3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
w1     = cr+"Sam Ryan"+cr2
w2     = "channel/UCsEqQf5Qtor5WPKO3hEUlXg"
w3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
x1     = cr1+"V Dub"+cr2
x2     = "channel/UCht9I2w2yNXQeH03a4f9D6w"
x3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
y1     = cr+"Peter Carcione"+cr2
y2     = "channel/UCQZcmkkx7hc0ik4wjaAtINQ"
y3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
z1     = cr1+"ASBYT"+cr2
z2     = "channel/UC18WQbNSfrqxlIjKeIW3bGQ"
z3     = 'http://dgsproduction.000webhostapp.com/thegrid/files/youtube.png'
###########################################################################################################
channellist=[ (a1, a2, a3),
              (b1, b2, b3),
              (c1, c2, c3),
              (d1, d2, d3),
              (e1, e2, e3),
              (f1, f2, f3),
              (g1, g2, g3),
              (h1, h2, h3),
              (i1, i2, i3),
              (j1, j2, j3),
              (k1, k2, k3),
              (l1, l2, l3),
              (m1, m2, m3),
              (n1, n2, n3),
              (o1, o2, o3),
              (p1, p2, p3),
              (q1, q2, q3),
              (r1, r2, r3),
              (s1, s2, s3),
              (t1, t2, t3),
              (u1, u2, u3),
              (v1, v2, v3),
              (w1, w2, w3),
              (x1, x2, x3),
              (y1, y2, y3),
              (z1, z2, z3),                          
            ]
###########################################################################################################

###########################################################################################################
#Please do not edit this code
def run():
    plugintools.log("youtubeAddon.run")
    params = plugintools.get_params()
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    plugintools.close_item_list()
###########################################################################################################

###########################################################################################################
#Please do not edit this code
def main_list(params):
    plugintools.log("youtubeAddon.main_list "+repr(params))
for name, id, icon in channellist:
    plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )
run()
###########################################################################################################